INSERT INTO `maintain_table` (`id`, `mt_time`, `user_id`, `mt_data_id`, `status`, `remark`, `sum`) VALUES (5, '2025-06-28 14:28:55', 1002, 19, '已维护', NULL, 1);
INSERT INTO `maintain_table` (`id`, `mt_time`, `user_id`, `mt_data_id`, `status`, `remark`, `sum`) VALUES (6, '2025-06-28 14:00:00', 1002, 20, '已维护', NULL, 1);
INSERT INTO `maintain_table` (`id`, `mt_time`, `user_id`, `mt_data_id`, `status`, `remark`, `sum`) VALUES (7, '2025-06-28 15:43:21', NULL, 21, '未维护', NULL, 0);
