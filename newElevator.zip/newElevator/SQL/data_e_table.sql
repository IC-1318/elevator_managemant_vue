INSERT INTO `data_e_table` (`id`, `create_time`, `system_name`, `system_sq_name`, `e_name`, `e_data`) VALUES (17, '2025-06-28 11:33:39', '曳引系统', '设备名字', '测试一下维护记录', 97.58);
INSERT INTO `data_e_table` (`id`, `create_time`, `system_name`, `system_sq_name`, `e_name`, `e_data`) VALUES (18, '2025-06-28 12:20:24', '门系统', '设备名字', '测试一下维护记录', 98.88);
INSERT INTO `data_e_table` (`id`, `create_time`, `system_name`, `system_sq_name`, `e_name`, `e_data`) VALUES (19, '2025-06-28 14:11:46', '门系统', '设备名字', '测试一下维护记录', 98.88);
INSERT INTO `data_e_table` (`id`, `create_time`, `system_name`, `system_sq_name`, `e_name`, `e_data`) VALUES (20, '2025-06-28 14:12:47', '曳引系统', '设备名字', '测试时间次数', 98.88);
INSERT INTO `data_e_table` (`id`, `create_time`, `system_name`, `system_sq_name`, `e_name`, `e_data`) VALUES (21, '2025-06-28 15:43:21', '曳引系统', '设备名字', '测试数据库', 98.88);
