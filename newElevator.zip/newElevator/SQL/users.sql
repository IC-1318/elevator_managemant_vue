INSERT INTO `users` (`id`, `user_name`, `user_phone`, `position`) VALUES (1002, '王大锤', '155555558791', '待分配');
INSERT INTO `users` (`id`, `user_name`, `user_phone`, `position`) VALUES (1006, '胡佳佳', '1967658813791', '待分配');
INSERT INTO `users` (`id`, `user_name`, `user_phone`, `position`) VALUES (10011, '李芯湉', '1875357813791', '待分配');
INSERT INTO `users` (`id`, `user_name`, `user_phone`, `position`) VALUES (10089, '唐琪婉', '1875658813791', '待分配');
