package com.example.V1.entity;

//AI 知识库实体
public class PromptKnowledge {
    private String prompt;
    private String completion;

    // getter和setter
    public String getPrompt() { return prompt; }
    public void setPrompt(String prompt) { this.prompt = prompt; }
    public String getCompletion() { return completion; }
    public void setCompletion(String completion) { this.completion = completion; }
}
