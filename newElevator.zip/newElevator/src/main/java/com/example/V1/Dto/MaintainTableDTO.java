package com.example.V1.Dto;

import lombok.Getter;

@Getter
public class MaintainTableDTO {
    private String status;
    private String remark;
    private Integer userId;
    private Integer id;
    private int sum;
}
